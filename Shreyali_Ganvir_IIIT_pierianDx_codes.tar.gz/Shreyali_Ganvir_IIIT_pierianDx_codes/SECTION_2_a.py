#!/usr/bin/python

import MySQLdb as db


conn = db.connect("localhost", "root","admin123")    			# Open database connection
cur = conn.cursor()                                                		# prepare a cursor object using cursor() method


# execute SQL query using execute() method.
cur.execute("CREATE DATABASE testsection2")


conn.close()                                                       	# disconnect from server


