#!/usr/bin/python

import MySQLdb as db


# connection with database MySql ( MySql database is been already created in SECTION_2_3_a.py )
# here, we create an object "conn" for connecting to database through root

conn= db.connect("localhost", "root","admin123","MySql") 

# creating cur object using cursor() method 
cur = conn.cursor()
# opening file to load mutations into database
f1 = open("mutect_immediate.vcf")
lines1 = f1.readlines()

print "Inserting values of mutation in my_vcf table\n"
for i in range(len(lines1)):
	if not lines1[i].startswith('#'):
		lines1[i] = lines1[i].rstrip()		
		b1 = lines1[i].split("\t") 

		cur.execute('INSERT INTO my_vcf(Chr,Pos,ID,Ref,Alt,Qual,Filter,Info,Sample)VALUES("%s","%d","%s","%s","%s","%s","%s","%s","%s")' % (b1[0],int(b1[1]),b1[2],b1[3],b1[4],b1[5],b1[6],b1[7],b1[8]))

print "Fetching mutations with quality >50 and	<500\n"	
try:
	cur.execute("SELECT * FROM my_vcf WHERE Qual > 50 and Qual < 500 INTO OUTFILE 'outfile_section3.3.c'")
except:
	conn.close()
