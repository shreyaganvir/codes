#!/usr/bin/python

import MySQLdb as db


# connection with database MySql ( MySql database is been already created in SECTION_2_3_a.py )
# here, we create an object "conn" for connecting to database through root

conn= db.connect("localhost", "root","admin123","MySql") 

# creating cur object using cursor() method 
cur = conn.cursor()	

# sql query to delete table if the tabel of given name already exists
cur.execute("DROP TABLE IF EXISTS my_vcf")

#sql query stored in a variable named q for creating table my_vcf with the following
# Pos column has primary key because other columns does not seem to have any unique values

q = "CREATE TABLE my_vcf (Chr VARCHAR(7) , Pos INT PRIMARY KEY, Id VARCHAR(15), Ref VARCHAR(3), Alt VARCHAR(3), Qual VARCHAR(7), Filter VARCHAR(20), Info VARCHAR(30) ,Sample VARCHAR(100))"

# execute the query assigned to variable q under execute command
cur.execute(q)




