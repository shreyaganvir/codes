#!/usr/bin/python

print "SECTION 1."

# defining  a function to read,write and execute the task

def read_write_files():
	
	# opening multiple files with "with" function
	print "opening file mutect_immediate.vcf"
	print "opening file truseq.bed"
	print "======================="

	with open("mutect_immediate.vcf") as f1, open("truseq.bed") as f2 , open("accepted.xls","w") as f3:
		f3.write(str("CHROM")+str(",")+str("POS")+str(",")+str("ID")+str(",")+str(",")+str("REF")+str(",")+str("ALT")+str(",")+str("QUAL")+str(",")+str("FILTER")+str(",")+str("INFO")+str(",")+str("FORMAT")+str(",")+str("none")+str(",")+str("LungCancer")+str(",")+str(",")+str(",")+str("\n"))

		# store the files into a list
		lines1 = f1.readlines()
		lines2 = f2.readlines()

		# outer loop for truseq.bed file
		for i in range(len(lines2)):
			
			# to remove the newline charachter for truseq.bed file
			lines2[i] = lines2[i].rstrip()
		
			# to split the list based on tab seperated delimiter for truseq.bed file
			b2 = lines2[i].split("\t")

			# inner loop for mutect_immediate.vcf file. The truseq.bed loop will iterate over this loop
			for j in range(len(lines1)):
			
				# to remove the newline charachter for mutect_immediate.vcf file
				lines1[j] = lines1[j].rstrip()

				# to extract only those lines that do not starts with "#"
				if not lines1[j].startswith('#'):
					
					# to split the list based on tab seperated delimiter for mutect_immediate.vcf file
					b1 = lines1[j].split("\t")
				
					# check chromosome no for both files
					if b2[0] == b1[0]:
					
						# check if position of chromosome mutation is within the panel range 						
						if ((int(b1[1]) >= int(b2[1])) and (int(b1[1]) <= int(b2[2]))):
							
							# write to file pointer f3 = "accepted.xls"
							print >>f3,str(b1[0])+str(",")+str(b1[1])+str(",")+str(b1[2])+str(",")+str(b1[3])+str(",")+str(b1[4])+str(",")+str(b1[5])+str(",")+str(b1[6])+str(",")+str(b1[7])+str(",")+str(b1[8])+str(",")+str(b1[9])+str(",")+str(b1[10])				
		print "Writing accepted mutations to accepted.xls file"
		print "==============================================="
	print "Done"
	

			 			
read_write_files()	
