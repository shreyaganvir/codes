#!/usr/bin/python

import MySQLdb as db


conn = db.connect("localhost", "root","admin123","testsection2")    			# Open database connection
cur = conn.cursor()                                                			# prepare a cursor object using cursor() method
cur.execute("CREATE TABLE test (eid INT PRIMARY KEY, name VARCHAR(20) NOT NULL,  age INT)")	# create table named "test" with 3 columns	
cur.execute("INSERT INTO test VALUES(1234, 'Alice', 24)")

cur.execute("INSERT INTO test VALUES(4321, 'Bob', 35)")						# inserting values

cur.execute("INSERT INTO test VALUES(6789, 'Chris', 40)")

cur.execute("INSERT INTO test VALUES(9876, 'Dan', 29)")

sql = "DELETE FROM test WHERE AGE > '%d'" % (20)				#deleting rows
cur.execute(sql)

conn.close() 		                                  

