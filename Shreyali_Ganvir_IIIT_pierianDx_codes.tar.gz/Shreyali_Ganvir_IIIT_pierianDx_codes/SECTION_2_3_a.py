#!/usr/bin/python

import MySQLdb as db

conn= db.connect("localhost", "root","admin123")	# Open database connection 
cur = conn.cursor()					# object cur for method cursor()		         

sql = "CREATE DATABASE MySql"				# database name "MySql"
							# variable q for the query			
cur.execute(sql)					# execute variable q that consist query
 
