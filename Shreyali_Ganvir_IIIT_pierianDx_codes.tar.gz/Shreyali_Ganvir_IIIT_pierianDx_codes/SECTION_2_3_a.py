#!/usr/bin/python

import MySQLdb as db

conn= db.connect("localhost", "root","admin123") 
cursor = conn.cursor()			         # Open database connection

sql = "CREATE DATABASE MySql"
cursor.execute(sql)	
 
